from enum import Enum
import numpy as np 
import math
import cv2
from sklearn.preprocessing import MinMaxScaler

class Pixel:
    def  __init__(self, x,y,v=0):
        self.x=x
        self.y=y
        self.value=np.uint16(v)
    
class MyPlane(Enum):
    HORIZONTAL=1
    VERTICAL=2
    DIAGONAL_TOP_LEFT=3
    DIAGONAL_TOP_RIGHT=4
    DIAGONAL_BOTTOM_LEFT=5
    DIAGONAL_BOTTOM_RIGHT=6
    
class SlicerDirection (Enum):
    SAGGITAL = 1 # from right to left
    CORONAL = 2 # from front to back 
    AXIAL = 3 # from top to bottom
    
class MeasureCortexThickness:
    def __init__(self, img3d):
        self.img3d = img3d
        self.left_bound = 0
        self.top_bound = 0
        self.bottom_bound = 0
        self.right_bound = 0
        self.image_slice = []
        self.foundNeighbors = []
        self.original = []
        self.mask =[]

    def isBoundary(self, pixel, plane):
        '''Returns true if you have hit the boundary'''
        
        #Horizontal boundary check
        if(plane == MyPlane.HORIZONTAL):
            if(pixel.x <= self.left_bound or pixel.x >= self.right_bound):
                return True
        elif(plane == MyPlane.VERTICAL):
            if(pixel.y <= self.top_bound or pixel.y >= self.bottom_bound):
                return True
        elif(plane == MyPlane.DIAGONAL_TOP_RIGHT):
            if(pixel.x >= self.right_bound or pixel.y <= self.top_bound):
                return True
        elif(plane == MyPlane.DIAGONAL_TOP_LEFT):
            if(pixel.x <= self.left_bound or pixel.y <= self.top_bound):
                return True
        elif(plane == MyPlane.DIAGONAL_BOTTOM_RIGHT):
            if(pixel.x >= self.right_bound or pixel.y >= self.bottom_bound):
                return True
        elif(plane == MyPlane.DIAGONAL_BOTTOM_LEFT):
            if(pixel.x <= self.left_bound or pixel.y >= self.bottom_bound):
                return True

        return False
        
        
    def inNeighborhood(self,pixel):
        for p in self.foundNeighbors:
            if(p.value == pixel.value and p.x == pixel.x and p.y==pixel.y):
                return True;
            else:
                return False;
    def getNeighborhood(self, pixel):
        pass
            
    def scan(self, startPixel):

        hor_neighborhood = []  # Horizontal neighborhood
        ver_neighborhood = []  # Horizontal neighborhood
        top_right_neighborhood = []  # top_right neighborhood
        top_left_neighborhood = []  # top_left neighborhood
        bottom_right_neighborhood = []  # bottom_right neighborhood
        bottom_left_neighborhood = []  # bottom_left neighborhood

        
        left_pixel = startPixel;
        right_pixel = startPixel;
        top_pixel = startPixel;
        bottom_pixel = startPixel;
        
        # Diagonals
        top_right_pixel = startPixel; #decrease x, increase y
        top_left_pixel = startPixel; #decrease x, decrease y
        bottom_right_pixel =startPixel; #increase x, increase y
        bottom_left_pixel = startPixel; #increase x, decrease y
        
       
        if(startPixel.value>0):
            hor_neighborhood.append(startPixel)
            ver_neighborhood.append(startPixel)
            top_right_neighborhood.append(startPixel) 
            top_left_neighborhood.append(startPixel) 
            bottom_right_neighborhood.append(startPixel)
            bottom_left_neighborhood.append(startPixel) 
        else:
            return startPixel;
        
        can_grow_right = True 
        can_grow_left = True 
        can_grow_top = True 
        can_grow_bottom = True
        can_grow_top_right = True 
        can_grow_top_left = True 
        can_grow_bottom_right = True
        can_grow_bottom_left = True 

        while(True):
            if(startPixel.value<=0):
                break
            found = False
            # Horizontal left scan
            left_pixel = Pixel(left_pixel.x-1,left_pixel.y);
            if(can_grow_left and (not self.isBoundary(left_pixel, MyPlane.HORIZONTAL))):
                left_pixel.value = self.image_slice[left_pixel.x,left_pixel.y]
                if(left_pixel.value>0):
                    hor_neighborhood.append(left_pixel)
                    found = True
                else:
                    can_grow_left = False
                    
                    
            # Horizontal right scan    
            right_pixel = Pixel(right_pixel.x+1,right_pixel.y);
            if(can_grow_right and (not self.isBoundary(right_pixel, MyPlane.HORIZONTAL))):
                right_pixel.value = self.image_slice[right_pixel.x,right_pixel.y]
                if(right_pixel.value>0):
                    hor_neighborhood.append(right_pixel)
                    found = True
                else:
                    can_grow_right = False    
                    
                    
            # Vertical top scan
            top_pixel = Pixel(top_pixel.x,top_pixel.y-1);
            if(can_grow_top and (not self.isBoundary(top_pixel, MyPlane.VERTICAL))):
                top_pixel.value = self.image_slice[top_pixel.x][top_pixel.y]
                if(top_pixel.value>0):
                    ver_neighborhood.append(top_pixel)
                    found = True
                else:
                    can_grow_top = False    
                         
                    
                    
            # Vertical bottom scan
            bottom_pixel = Pixel(bottom_pixel.x,bottom_pixel.y+1);
            if(can_grow_bottom and (not self.isBoundary(bottom_pixel, MyPlane.VERTICAL))):
                bottom_pixel.value = self.image_slice[bottom_pixel.x,bottom_pixel.y]
                if(bottom_pixel.value>0):
                    ver_neighborhood.append(bottom_pixel)
                    found = True
                else:
                    can_grow_bottom = False    
                    
            
            # top right scan
            top_right_pixel = Pixel(top_right_pixel.x+1,top_right_pixel.y-1);
            if(can_grow_top_right and (not self.isBoundary(top_right_pixel, MyPlane.DIAGONAL_TOP_RIGHT))):
                top_right_pixel.value = self.image_slice[top_right_pixel.x,top_right_pixel.y]
                if(top_right_pixel.value>0):
                    top_right_neighborhood.append(top_right_pixel)
                    found = True
                else:
                    can_grow_top_right = False    
                    
                    
            # top left scan
            top_left_pixel = Pixel(top_left_pixel.x-1,top_left_pixel.y-1);
            if(can_grow_top_left and  (not self.isBoundary(top_left_pixel, MyPlane.DIAGONAL_TOP_LEFT))):
                top_left_pixel.value = self.image_slice[top_left_pixel.x,top_left_pixel.y]
                if(top_left_pixel.value>0):
                    top_left_neighborhood.append(top_left_pixel)
                    found = True
                else:
                    can_grow_top_left = False    
                    
                    
             # bottom left scan
            bottom_left_pixel = Pixel(bottom_left_pixel.x-1,bottom_left_pixel.y+1);
            if(can_grow_bottom_left and (not self.isBoundary(bottom_left_pixel, MyPlane.DIAGONAL_BOTTOM_LEFT))):
                bottom_left_pixel.value = self.image_slice[bottom_left_pixel.x,bottom_left_pixel.y]
                if(bottom_left_pixel.value>0):
                    bottom_left_neighborhood.append(bottom_left_pixel)
                    found = True
                else:
                    can_grow_bottom_left = False    
                    
            
            
            # bottom right scan
            bottom_right_pixel = Pixel(bottom_right_pixel.x+1,bottom_right_pixel.y+1);
            if(can_grow_bottom_right and (not self.isBoundary(bottom_right_pixel, MyPlane.DIAGONAL_BOTTOM_RIGHT))):
                bottom_right_pixel.value = self.image_slice[bottom_right_pixel.x,bottom_right_pixel.y]
                if(bottom_right_pixel.value>0):
                    bottom_right_neighborhood.append(bottom_right_pixel)
                    found = True
                else:
                    can_grow_bottom_right = False    
                    
            if(not found):
                   break 
        # ----- While loop ends
        if(startPixel.value >0):
            count = np.array([len(hor_neighborhood), len(ver_neighborhood), len(top_right_neighborhood), 
                              len(top_left_neighborhood), len(bottom_right_neighborhood), len(bottom_left_neighborhood)])
            min_count = np.min(count);
            count[count<=1]=0;
            # print(count);
            if(len(count)>0 and np.sum(count) ==np.sort(count)[len(count)-1]):
                startPixel.value = 1;
                return startPixel
            
            # min_length = np.sum(count)/len(count)
            # min_length = np.min(count)
            startPixel.value = np.uint16(math.pi*(min_count**2));
        return startPixel;
    
            
            
                        
    def start(self, layer=None, direction=SlicerDirection.AXIAL):

        threshold_top = .65*np.max(self.img3d.ravel());
        threshold_bottom = .25*np.max(self.img3d.ravel()); 
        self.img3d[self.img3d>threshold_top]=0
        self.img3d[self.img3d<threshold_bottom]=0
        
        # Handling rectangular 3d dimensions
        image_length = self.img3d.shape[0];
        #if(len(self.img3d.shape)>1):
        if(direction==SlicerDirection.AXIAL):
            image_length = self.img3d.shape[2];   
        elif(direction==SlicerDirection.CORONAL):
            image_length = self.img3d.shape[1];  
        elif(direction==SlicerDirection.SAGGITAL):
            image_length = self.img3d.shape[0];
            
        for l in range(0, image_length): # step and fetch layers in the specified plan
            if not(layer == None):
                l =layer;
                
            self.original, self.mask = self.sliceThrough(l, direction)
            self.image_slice = self.mask
            self.bottom_bound =self.image_slice.shape[1]
            self.right_bound = self.image_slice.shape[0]
            self.image_slice = self.image_slice
            # print(len(self.mask))
            
            slice_copy = np.copy(self.mask);
            
            for x in range(0, self.right_bound):
                for y in range(0, self.bottom_bound):
                    pixel = Pixel(x,y,self.image_slice[x,y]);
                    pixel = self.scan(pixel) #return calculated pixel with value
                    slice_copy[x,y]= pixel.value;
        
            scaler = MinMaxScaler(feature_range=(0,255));
            slice_copy = scaler.fit_transform(slice_copy);
            slice_copy = np.array(slice_copy,dtype=np.uint16)       
            
            if not(layer == None):
                return slice_copy; #return copy of the slice
            else:
                # replace sliced copy into the 3d image data
                if(direction==SlicerDirection.AXIAL):
                    self.img3d[:,l:l+1,:] = slice_copy.reshape(slice_copy.shape[0],1,slice_copy.shape[1])
                elif(direction==SlicerDirection.CORONAL):
                     self.img3d[:,:,l:l+1] = slice_copy.reshape(slice_copy.shape[0],slice_copy.shape[1],1)
                elif(direction==SlicerDirection.SAGGITAL):
                     self.img3d[l:l+1,:,:] = slice_copy.reshape(1,slice_copy.shape[0],slice_copy.shape[1])
            print('Processing .... ', int((l/image_length)*100),"%")
        print('Processing complete')
        return self.img3d

    
    
    
    def sliceThrough(self, layer, direction=SlicerDirection.AXIAL):
        '''Slices and threshold the image to removes noise '''
        slice_ = []

        if(direction == SlicerDirection.SAGGITAL):
            slice_ = self.img3d[layer,:,:].T; #Slicing from left to right
        elif(direction == SlicerDirection.CORONAL):
            slice_ =  self.img3d[:,:,layer].T; #Slicing from front to back
        elif(direction == SlicerDirection.AXIAL):
            slice_= self.img3d[:,layer,:].T; #Slicing from top to bottom

        original_slice = np.copy(slice_);

        # Threshold to remove noise
        slice_[slice_>.75*np.max(slice_)]=1; #Top 75% set considered to be white
        slice_[slice_<.25*np.max(slice_)]=0; #Lowest 25% is considered black
        # Apply the Component analysis function
        analysis = cv2.connectedComponentsWithStats(np.uint8(slice_), 4, cv2.CV_32S)
        (totalLabels, label_ids, values, centroid) = analysis
    
        # Initialize a new image to store
        # all the output components
        self.mask  = np.zeros(slice_.shape, dtype=np.uint16)
        masks = []
    
        # # Loop through each component
        j=0
        for i in range(1, totalLabels):
            if(j<2):
                j=j+1
                continue
            # Area of the component
            area = values[i, cv2.CC_STAT_AREA]
            if (area > 500):
                if(centroid[i][0]<97 or centroid[i][0]>=165):
                    continue
                if(centroid[i][1]<95 or centroid[i][1]>=150):
                    continue
                # # print(area)
                # print(centroid[i][0])
                componentMask = (label_ids == i)#.astype("uint8")
                componentMask[componentMask>0]=1;
                componentMask = componentMask.astype(np.uint16)
                masks.append(componentMask)
                self.mask  =  np.bitwise_or(self.mask ,componentMask)
                
                # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2,2))
                # self.masks  = cv2.erode(self.masks , kernel, iterations=1)
                # self.masks  = cv2.dilate(self.masks , kernel,iterations=1)
            
                self.original = np.multiply(original_slice,self.mask); 
        
        return  self.original, self.mask;






if __name__ == '__main__':
    pass